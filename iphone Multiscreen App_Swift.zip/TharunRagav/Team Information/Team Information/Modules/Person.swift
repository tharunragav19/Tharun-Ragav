//
//  Person.swift
//  MultiScreen App
//
//  Created by Tharun Raghuraman Ragav on 11/02/2025.
//

import Foundation

class Person{
    // properties
    var name, role, matches, average, image, url, style : String
    
    // init
    init(name: String, role: String, matches: String, average: String, image: String, url:String, style:String) {
        self.name = name
        self.role = role
        self.matches = matches
        self.average = average
        self.image = image
        self.url = url
        self.style = style
    }
}
