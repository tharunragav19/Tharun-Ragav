//
//  People.swift
//  People Multi Screen
//
//  Created by Tharun Raghuraman Ragav on 11/02/2025.
//

import Foundation

class People{
    // properties
    var people : [Person]
    
    // init
    init(people: [Person]) {
        self.people = people
    }
    init(){
        self.people =
        [
            Person(name:"Rohit Sharma", role: "Batsman/Captain", matches:"268", average:"49.05", image:"Rohit Sharma.jpeg", url:"https://www.espncricinfo.com/cricketers/rohit-sharma-34102", style:"Right Hand Bat/Right Arm Off-break"),
            Person(name:"Shubman Gill", role: "Batsman/Vice-Captain", matches:"50", average:"60.16", image:"Shubman Gill.jpeg", url:"", style:""),
            Person(name:"Virat Kohli", role: "Batsman", matches:"297", average:"57.93", image:"Virat Kohli.jpeg", url:"", style:""),
            Person(name:"Shreyas Iyer", role: "Batsman", matches:"65", average:"48.18", image:"Shreyas Iyer.jpeg", url:"", style:""),
            Person(name:"KL Rahul", role: "Batsman", matches:"80", average:"47.59", image:"KL Rahul.jpeg", url:"", style:""),
            Person(name:"Rishabh Pant", role: "Batsman/Wicket Keeper", matches:"31", average:"33.50", image:"Rishabh Pant.jpeg", url:"", style:""),
            Person(name:"Hardik Pandya", role: "All-rounder", matches:"89", average:"33.42", image:"Hardik Pandya.jpeg", url:"", style:""),
            Person(name:"Axar Patel", role: "All-rounder", matches:"63", average:"21.74", image:"Axar Patel.jpeg", url:"", style:""),
            Person(name:"Washington Sundar", role: "All-rounder", matches:"23", average:"27.87", image:"Washington Sundar.jpeg", url:"", style:""),
            Person(name:"Ravindra Jadeja", role: "All-rounder", matches:"199", average:"32.69", image:"Ravindra Jadeja.jpeg", url:"", style:""),
            Person(name:"Kuldeep Yadav", role: "Bowler", matches:"108", average:"26.22", image:"Kuldeep Yadav.jpeg", url:"", style:""),
            Person(name:"Harshit Rana", role: "Bowler", matches:"3", average:"24.33", image:"Harshit Rana.jpeg", url:"", style:""),
            Person(name:"Mohammed Shami", role: "Bowler", matches:"103", average:"23.96", image:"Mohammed Shami.jpeg", url:"", style:""),
            Person(name:"Arshdeep Singh", role: "Bowler", matches:"9", average:"23.00", image:"Arshdeep Singh.jpeg", url:"", style:""),
            Person(name:"Varun Chakravarthy", role: "Bowler", matches:"1", average:"54.00", image:"Varun Chakravarthy.jpeg", url:"", style:""),
            Person(name:"Yashasvi Jaiswal", role: "Batsman(sub)", matches:"1", average:"15.00", image:"Yashasvi Jaiswal.jpeg", url:"", style:""),
            Person(name:"Mohammed Siraj", role: "Bowler(sub)", matches:"44", average:"24.04", image:"Mohammed Siraj.jpeg", url:"", style:""),
            Person(name:"Shivam Dube", role: "All-rounder(sub)", matches:"4", average:"10.75", image:"Shivam Dube.jpeg", url:"", style:""),
            Person(name:"Gautam Gambhir", role: "Head Coach", matches:"-", average:"-", image:"Gautam Gambhir.jpeg", url:"", style:""),
            
        ]
    }
    
    init(xmlFile:String){
        // make an XML People Parser and start parsing
        let peopleParser = xmlPeople(fileName: xmlFile)
        peopleParser.startParsing()
        
        // get the parsed data
        self.people = peopleParser.peopleData
        
    }
    
    
    //methods
    func count()->Int{return self.people.count}
    func person(index:Int)->Person{return self.people[index]}
}
