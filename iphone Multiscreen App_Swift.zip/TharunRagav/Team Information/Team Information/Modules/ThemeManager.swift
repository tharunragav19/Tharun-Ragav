import UIKit

class ThemeManager {
    static let shared = ThemeManager()
    
    // Use a consistent key for saving the theme
    private let themeKey = "isDarkMode"
    
    // Check current theme using the consistent key
    var isDarkMode: Bool {
        return UserDefaults.standard.bool(forKey: themeKey)
    }
    
    // Set the theme and notify all screens about the change
    func setTheme(_ darkMode: Bool) {
        UserDefaults.standard.set(darkMode, forKey: themeKey)
        NotificationCenter.default.post(name: NSNotification.Name("ThemeChanged"), object: nil)
    }
    
    // Apply theme to a given view controller
    func applyTheme(to viewController: UIViewController) {
        if isDarkMode {
            viewController.view.backgroundColor = .black
            viewController.navigationController?.navigationBar.barTintColor = .darkGray
            viewController.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        } else {
            viewController.view.backgroundColor = .systemYellow
            viewController.navigationController?.navigationBar.barTintColor = .systemYellow
            viewController.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.black]
        }
    }
}
