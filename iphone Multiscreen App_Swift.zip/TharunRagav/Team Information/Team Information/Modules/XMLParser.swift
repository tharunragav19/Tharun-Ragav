//
//  xmlPeople.swift
//  PeopleInformation
//
//  Created by Tharun Raghuraman Ragav on 25/02/2025.
//

import Foundation

class xmlPeople:NSObject,XMLParserDelegate{
    
    var fileName : String
    
    init(fileName: String) {
        self.fileName = fileName
    }
    
    //MARK: - vars for parsing
    
    // p-var to store data
    var pName, pRole, pMatches, pAverage, pImage, pUrl, pStyle: String!
    
    //sky vars
    var passData = false
    var passElement:Int = -1
    
    // data vars
    var personData : Person!
    var peopleData : [Person] = [Person]()
    
    //parsing vars
    var parser : XMLParser!
    let tags = ["name", "role", "matches", "average", "image", "url", "style"]
    
    
    //MARK: - parsing delegate methods
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        // check the elementName tag and spy it
        if tags.contains(elementName){
            // reset the spys
            passData = true
            passElement = tags.firstIndex(of: elementName)!
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // use the spys to store string in pvars
        if passData{
            // check passElement to store string in var
            switch passElement{
                case 0: pName = string
                case 1: pRole = string
                case 2: pMatches = string
                case 3: pAverage = string
                case 4: pImage = string
                case 5: pUrl = string
                case 6: pStyle = string
                default: break
            }
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        //reset the spys
        if tags.contains(elementName){
            passData = false
            passElement = -1
            
        }
        
        // check if elementName is person
        if elementName == "person"{
            personData = Person(name: pName, role: pRole, matches: pMatches, average: pAverage, image: pImage, url: pUrl, style: pStyle)
            peopleData.append(personData)
        }
    }
    
    func startParsing(){
        //get the url of the fileName
        
        let bundleURL = Bundle.main.bundleURL
        let fileURL   = URL(string: self.fileName, relativeTo: bundleURL)
        
        //make the parse and delegate it
        parser = XMLParser(contentsOf: fileURL!)
        parser.delegate = self
        
        //parse
        parser.parse()
    }
}
