//
//  WebViewController 2.swift
//  Assignment 1
//
//  Created by Tharun Raghuraman Ragav on 26/02/2025.
//


//
//  WebViewController.swift
//  MultiScreen App
//
//  Created by Tharun Raghuraman Ragav on 11/02/2025.
//

import UIKit

import WebKit

class WebViewController: UIViewController {
    
    //MARK: ~ Outkets
    
    var urlData : String!
    
    @IBOutlet weak var personWebView: WKWebView!
    
    @IBOutlet weak var themeSwitch: UISwitch!

    

    @IBAction func switchTheme(_ sender: UISwitch) {
        ThemeManager.shared.setTheme(sender.isOn)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Player Web View"
        
        self.navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: UIColor.blue 
           ]
        
        ThemeManager.shared.applyTheme(to: self)
            
            // Listen for theme change notification
        NotificationCenter.default.addObserver(self, selector: #selector(updateTheme), name: NSNotification.Name("ThemeChanged"), object: nil)


        let urlWeb = URL(string: urlData) ?? URL(string: "https://www.rte.ie/")
        let webURLRequest = URLRequest(url: urlWeb!)
        personWebView.load(webURLRequest)
    }
    
    @objc func updateTheme() {
        ThemeManager.shared.applyTheme(to: self)
    }
    


}
