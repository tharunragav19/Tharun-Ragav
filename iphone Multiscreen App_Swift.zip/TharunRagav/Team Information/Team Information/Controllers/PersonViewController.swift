//
//  PersonViewController.swift
//  MultiScreen App
//
//  Created by Tharun Raghuraman Ragav on 11/02/2025.
//

import UIKit

class PersonViewController: UIViewController {
    
    
    @IBOutlet weak var personImageView: UIImageView!
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBAction func moreInfoAction(_ sender: Any) {

    }
    @IBOutlet weak var themeSwitch: UISwitch!

    
    @IBOutlet weak var nameTag: UILabel!
    
    
    // model data
    var personData : Person!
    
    override func viewDidLoad() {
            super.viewDidLoad()
            self.title = "Player Information"
            
            // Set title text color
            self.navigationController?.navigationBar.titleTextAttributes = [
                .foregroundColor: UIColor.blue
            ]
            
            // Apply saved theme
            ThemeManager.shared.applyTheme(to: self)
            
            // Listen for theme change notifications
            NotificationCenter.default.addObserver(self, selector: #selector(updateTheme), name: NSNotification.Name("ThemeChanged"), object: nil)
            
            // Populate UI elements
            nameLabel.text = personData.name
            personImageView.image = UIImage(named: personData.image)
            nameTag.textColor = UIColor.blue
            
            // Set switch state based on saved theme
            themeSwitch.isOn = ThemeManager.shared.isDarkMode
        }
        
        @IBAction func switchTheme(_ sender: UISwitch) {
            // Use ThemeManager to update and save the theme
            ThemeManager.shared.setTheme(sender.isOn)
        }
        
        @objc func updateTheme() {
            ThemeManager.shared.applyTheme(to: self)
        }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segue1"{
            let destinationController = segue.destination as! DetailViewController
            destinationController.personData = self.personData
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
    }
    

    
  
        
    

}
