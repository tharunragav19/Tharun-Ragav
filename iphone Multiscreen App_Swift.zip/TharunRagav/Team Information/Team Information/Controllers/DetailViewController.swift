//
//  DetailViewController.swift
//  Assignment 1
//
//  Created by Tharun Raghuraman Ragav on 25/02/2025.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    @IBOutlet weak var roleLabel: UILabel!
    
    @IBOutlet weak var matchesLabel: UILabel!
    
    
    @IBOutlet weak var averageLabel: UILabel!
    
    @IBOutlet weak var styleLabel: UILabel!
    
    
    @IBOutlet weak var roleTag: UILabel!
    
    @IBOutlet weak var matchesTag: UILabel!
    
    @IBOutlet weak var averageTag: UILabel!
    
    
    @IBOutlet weak var styleTag: UILabel!
    
    
    @IBAction func webInfoAction(_ sender: Any) {
    }
    
    @IBOutlet weak var themeSwitch: UISwitch!

    


    
    var personData: Person!
    
    override func viewDidLoad() {
            super.viewDidLoad()
            self.title = "Player Details"
            
            // Set initial title text color
            self.navigationController?.navigationBar.titleTextAttributes = [
                .foregroundColor: UIColor.blue
            ]
            
            // Apply saved theme
            ThemeManager.shared.applyTheme(to: self)
            
            // Listen for theme changes
            NotificationCenter.default.addObserver(self, selector: #selector(updateTheme), name: NSNotification.Name("ThemeChanged"), object: nil)
            
            // Populate UI elements with person data
            roleLabel.text = personData.role
            matchesLabel.text = personData.matches
            averageLabel.text = personData.average
            styleLabel.text = personData.style
            
            roleTag.textColor = UIColor.blue
            matchesTag.textColor = UIColor.blue
            averageTag.textColor = UIColor.blue
            styleTag.textColor = UIColor.blue
            
            // Set switch state based on saved theme
            themeSwitch.isOn = ThemeManager.shared.isDarkMode
        }
        
        @IBAction func switchTheme(_ sender: UISwitch) {
            ThemeManager.shared.setTheme(sender.isOn)
        }
        
        @objc func updateTheme() {
            ThemeManager.shared.applyTheme(to: self)
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue2" {
            // get the new view controller
            let destinationController = segue.destination as! WebViewController
            // pass/match the data to the next screen
            destinationController.urlData = personData.url
        }
   
   
    }
    


}
