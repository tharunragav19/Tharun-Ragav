using UnityEngine;

    public class Trash : MonoBehaviour, IInteractable
    {
        public void Interact(PlayerController player)
        {
            player.held = null;
            player.RefreshHeldVisual();
        }
    }
