using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;
    public class Order
    {
        public List<IngredientType> required = new();
        public List<bool> fulfilled = new();
        public float spawnTime;

        public bool IsComplete => fulfilled.TrueForAll(f => f);

        public static Order GenerateRandom()
        {
            var o = new Order { spawnTime = Time.time };
            int count = Random.value < 0.5f ? 2 : 3;
            for (int i = 0; i < count; i++) {
                o.required.Add((IngredientType)Random.Range(0, 3));
                o.fulfilled.Add(false);
            }
            return o;
        }

        public int ScoreValue(IngredientType t) => t switch {
            IngredientType.Vegetable => 20,
            IngredientType.Cheese => 10,
            IngredientType.Meat => 30,
            _ => 0
        };

        public int ComputeScore() =>
            required.Sum(ScoreValue) - Mathf.FloorToInt(Time.time - spawnTime);
    }