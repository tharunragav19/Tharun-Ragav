using UnityEngine;

public class Fridge : MonoBehaviour, IInteractable
{
    public IngredientType type;
    public AudioSource audioSource;
    public AudioClip pickupSound;

    public void Interact(PlayerController player)
    {
        if (player.held != null) return;
        var state = type == IngredientType.Cheese ? IngredientState.Ready : IngredientState.Raw;
        player.held = new HeldIngredient { type = type, state = state };
        player.RefreshHeldVisual();

        if (audioSource != null && pickupSound != null)
            audioSource.PlayOneShot(pickupSound);
    }
}