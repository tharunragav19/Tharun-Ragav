using UnityEngine;
using TMPro;

public class PrepStation : MonoBehaviour, IInteractable
{
    public IngredientType acceptsType;
    public float prepSeconds;
    public int slotCount = 1;
    public TMP_Text[] slotTimerLabels;

    public Renderer stationRenderer;
    public Renderer[] slotMarkers;
    public Color inactiveColor = Color.white;
    public Color activeColor = Color.gray;
    public GameObject[] readyIndicators;

    public AudioSource audioSource;
    public AudioClip prepLoopSound; // chopping (Table) or cooking (Stove)

    class Slot { public bool occupied; public bool ready; public float timer; }
    Slot[] slots;

    void Awake() {
        slots = new Slot[slotCount];
        for (int i = 0; i < slotCount; i++) slots[i] = new Slot();
        if (stationRenderer == null) stationRenderer = GetComponent<Renderer>();
        RefreshVisuals();
    }

    void Update() {
        for (int i = 0; i < slots.Length; i++) {
            var s = slots[i];
            if (s.occupied) {
                s.timer -= Time.deltaTime;
                if (slotTimerLabels.Length > i)
                    slotTimerLabels[i].text = Mathf.Max(0, s.timer).ToString("F1");

                if (s.timer <= 0f) {
                    s.occupied = false;
                    s.ready = true;
                    if (slotTimerLabels.Length > i) slotTimerLabels[i].text = "";
                }
            }
        }
        RefreshVisuals();
    }

    void RefreshVisuals() {
        bool anySlotOccupied = false;
        for (int i = 0; i < slots.Length; i++) {
            bool occ = slots[i].occupied;
            anySlotOccupied |= occ;

            if (slotMarkers != null && slotMarkers.Length > i && slotMarkers[i] != null) {
                slotMarkers[i].gameObject.SetActive(occ);
                if (occ) slotMarkers[i].material.color = activeColor;
            }

            if (readyIndicators != null && readyIndicators.Length > i && readyIndicators[i] != null) {
                readyIndicators[i].SetActive(slots[i].ready);
            }
        }

        if ((slotMarkers == null || slotMarkers.Length == 0) && stationRenderer != null) {
            stationRenderer.material.color = anySlotOccupied ? activeColor : inactiveColor;
        }

        // Loop sound: play while at least one slot is busy, stop once none are
        if (audioSource != null && prepLoopSound != null) {
            if (anySlotOccupied && !audioSource.isPlaying) {
                audioSource.clip = prepLoopSound;
                audioSource.loop = true;
                audioSource.Play();
            } else if (!anySlotOccupied && audioSource.isPlaying) {
                audioSource.Stop();
            }
        }
    }

    public void Interact(PlayerController player)
    {
        if (player.held is HeldIngredient h && h.type == acceptsType && h.state == IngredientState.Raw)
        {
            for (int i = 0; i < slots.Length; i++)
                if (!slots[i].occupied && !slots[i].ready) {
                    slots[i].occupied = true;
                    slots[i].timer = prepSeconds;
                    player.held = null;
                    player.RefreshHeldVisual();
                    return;
                }
            return;
        }

        if (player.held == null)
        {
            for (int i = 0; i < slots.Length; i++)
                if (slots[i].ready) {
                    slots[i].ready = false;
                    player.held = new HeldIngredient { type = acceptsType, state = IngredientState.Ready };
                    player.RefreshHeldVisual();
                    return;
                }
        }
    }
}