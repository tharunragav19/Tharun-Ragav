using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    Rigidbody rb;
    Vector2 input;

    public HeldIngredient? held;
    public IInteractable currentTarget;

    public GameObject heldVisual;
    public Renderer heldVisualRenderer;

    public Material vegetableMaterial;
    public Material cheeseMaterial;
    public Material meatMaterial;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        if (heldVisualRenderer == null && heldVisual != null)
            heldVisualRenderer = heldVisual.GetComponent<Renderer>();
        RefreshHeldVisual();
    }

    void Update()
    {
        input.x = Input.GetAxisRaw("Horizontal");
        input.y = Input.GetAxisRaw("Vertical");

        if (Input.GetKeyDown(KeyCode.E)) currentTarget?.Interact(this);
    }

    void FixedUpdate()
    {
        Vector3 move = new Vector3(input.x, 0, input.y).normalized;
        rb.MovePosition(rb.position + move * moveSpeed * Time.fixedDeltaTime);
    }

    public void RefreshHeldVisual()
    {
        if (heldVisual == null) return;

        if (held == null)
        {
            heldVisual.SetActive(false);
            return;
        }

        heldVisual.SetActive(true);

        Material m = held.Value.type switch
        {
            IngredientType.Vegetable => vegetableMaterial,
            IngredientType.Cheese => cheeseMaterial,
            IngredientType.Meat => meatMaterial,
            _ => null
        };

        if (heldVisualRenderer != null && m != null)
            heldVisualRenderer.material = m;
    }
}