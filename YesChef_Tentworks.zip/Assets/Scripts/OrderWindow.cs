using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;

public class OrderWindow : MonoBehaviour, IInteractable
{
    public TMP_Text requiredLabel;
    public TMP_Text openTimerLabel;
    public TMP_Text scorePopupLabel;

    public AudioSource audioSource;
    public AudioClip itemDeliveredSound;
    public AudioClip orderCompleteSound;

    Order current;
    float respawnTimer = -1f;

    void Start() => SpawnOrder();

    void Update()
    {
        if (current != null) {
            openTimerLabel.text = Mathf.FloorToInt(Time.time - current.spawnTime) + "s";
        } else if (respawnTimer > 0) {
            respawnTimer -= Time.deltaTime;
            if (respawnTimer <= 0) SpawnOrder();
        }
    }

    void SpawnOrder() {
        current = Order.GenerateRandom();
        RefreshLabel();
    }

    void RefreshLabel() {
        requiredLabel.text = string.Join(", ", current.required
            .Select((t, i) => current.fulfilled[i] ? $"[{t}]" : t.ToString()));
    }

    public void Interact(PlayerController player)
    {
        if (current == null || player.held == null) return;
        var h = player.held.Value;
        if (h.state != IngredientState.Ready) return;

        int slot = -1;
        for (int i = 0; i < current.required.Count; i++)
            if (current.required[i] == h.type && !current.fulfilled[i]) { slot = i; break; }

        if (slot < 0) return; // not needed, stays in hand

        current.fulfilled[slot] = true;
        player.held = null;
        player.RefreshHeldVisual();
        RefreshLabel();

        if (audioSource != null && itemDeliveredSound != null)
            audioSource.PlayOneShot(itemDeliveredSound);

        if (current.IsComplete) CompleteOrder();
    }

    void CompleteOrder() {
        int score = current.ComputeScore();
        GameManager.Instance.AddScore(score);
        StartCoroutine(ShowPopup(score));

        if (audioSource != null && orderCompleteSound != null)
            audioSource.PlayOneShot(orderCompleteSound);

        current = null;
        requiredLabel.text = "";
        respawnTimer = 5f;
    }

    System.Collections.IEnumerator ShowPopup(int score) {
        scorePopupLabel.text = (score >= 0 ? "+" : "") + score;
        scorePopupLabel.alpha = 1;
        yield return new WaitForSeconds(1.5f);
        float t = 0;
        while (t < 1f) { t += Time.deltaTime; scorePopupLabel.alpha = 1 - t; yield return null; }
    }
}