using UnityEngine;

public class InteractZone : MonoBehaviour
{
    public PlayerController player; // drag the parent Player object in Inspector

    void OnTriggerEnter(Collider other) {
        if (other.TryGetComponent<IInteractable>(out var i)) player.currentTarget = i;
    }

    void OnTriggerExit(Collider other) {
        if (other.GetComponent<IInteractable>() == (object)player.currentTarget)
            player.currentTarget = null;
    }
}