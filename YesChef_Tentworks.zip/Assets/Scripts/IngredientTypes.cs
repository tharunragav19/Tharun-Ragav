    using UnityEngine;
    public enum IngredientType { Vegetable, Cheese, Meat }
    public enum IngredientState { Raw, Prepping, Ready }

    [System.Serializable]
    public struct HeldIngredient
    {
        public IngredientType type;
        public IngredientState state;
    }