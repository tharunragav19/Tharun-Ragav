using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("Start Panel")]
    public GameObject startPanel;
    public Button startButton;

    [Header("HUD")]
    public GameObject hudPanel;
    public TMP_Text scoreText;
    public TMP_Text highScoreText;
    public TMP_Text timerText;
    public Button pauseButton;
    public Button quitButton;

    [Header("Game Over Panel")]
    public GameObject gameOverPanel;
    public TMP_Text finalScoreText;
    public GameObject newHighScoreLabel; // simple text object, shown/hidden conditionally
    public Button resetButton;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        // Wire buttons in code as a backup/alternative to Inspector OnClick wiring
        if (startButton != null) startButton.onClick.AddListener(OnStartClicked);
        if (pauseButton != null) pauseButton.onClick.AddListener(OnPauseClicked);
        if (quitButton != null) quitButton.onClick.AddListener(OnQuitClicked);
        if (resetButton != null) resetButton.onClick.AddListener(OnResetClicked);

        ShowStartScreen();
    }

    void Update()
    {
        if (GameManager.Instance == null) return;

        if (GameManager.Instance.state == GameManager.State.Playing ||
            GameManager.Instance.state == GameManager.State.Paused)
        {
            UpdateHUD();
        }
    }

    void UpdateHUD()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + GameManager.Instance.GetScore();

        if (highScoreText != null)
            highScoreText.text = "High Score: " + PlayerPrefs.GetFloat("HighScore", 0);

        if (timerText != null)
        {
            float t = GameManager.Instance.GetTimeLeft();
            int minutes = Mathf.FloorToInt(t / 60f);
            int seconds = Mathf.FloorToInt(t % 60f);
            timerText.text = $"{minutes:00}:{seconds:00}";
        }
    }

    // ---------- Panel switching ----------

    void ShowStartScreen()
    {
        SetPanel(startPanel, true);
        SetPanel(hudPanel, false);
        SetPanel(gameOverPanel, false);
    }

    void ShowHUD()
    {
        SetPanel(startPanel, false);
        SetPanel(hudPanel, true);
        SetPanel(gameOverPanel, false);
    }

    public void ShowGameOver(int finalScore, bool isNewHighScore)
    {
        SetPanel(startPanel, false);
        SetPanel(hudPanel, false);
        SetPanel(gameOverPanel, true);

        if (finalScoreText != null)
            finalScoreText.text = "Final Score: " + finalScore;

        if (newHighScoreLabel != null)
            newHighScoreLabel.SetActive(isNewHighScore);
    }

    void SetPanel(GameObject panel, bool active)
    {
        if (panel != null) panel.SetActive(active);
    }

    // ---------- Button handlers ----------

    void OnStartClicked()
    {
        GameManager.Instance.StartGame();
        ShowHUD();
    }

    void OnPauseClicked()
    {
        GameManager.Instance.TogglePause();
    }

    void OnQuitClicked()
    {
        GameManager.Instance.Quit();
    }

    void OnResetClicked()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}