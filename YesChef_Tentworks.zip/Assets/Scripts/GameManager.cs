    using UnityEngine;
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;
        public float roundSeconds = 180f;
        float timeLeft;
        int score;
        public enum State { Menu, Playing, Paused, GameOver }
        public State state = State.Menu;

        void Awake() { Instance = this; }

        public void StartGame() {
            score = 0; timeLeft = roundSeconds; state = State.Playing;
        }

        void Update() {
            if (state != State.Playing) return;
            timeLeft -= Time.deltaTime;
            if (timeLeft <= 0) EndGame();
        }

        public void AddScore(int amount) => score += amount;
        public int GetScore() => score;
        public float GetTimeLeft() => Mathf.Max(0, timeLeft);

        void EndGame() {
            state = State.GameOver;
            float high = PlayerPrefs.GetFloat("HighScore", 0);
            bool isNew = score > high;
            if (isNew) PlayerPrefs.SetFloat("HighScore", score);
            UIManager.Instance.ShowGameOver(score, isNew);
        }

        public void TogglePause() {
            if (state == State.Playing) { state = State.Paused; Time.timeScale = 0; }
            else if (state == State.Paused) { state = State.Playing; Time.timeScale = 1; }
        }

        public void Quit() => Application.Quit();
    }